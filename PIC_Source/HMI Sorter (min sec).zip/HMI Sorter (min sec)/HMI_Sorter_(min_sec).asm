
_ems_halt:

;HMI_Sorter_(min_sec).c,103 :: 		void ems_halt() {                                                               // Pooling based "interruption preprocessor" due lack of memory
;HMI_Sorter_(min_sec).c,104 :: 		MOTOR_RUN = 0;
	BCF        PORTB+0, 2
;HMI_Sorter_(min_sec).c,105 :: 		SORT_OUT = 0;
	BCF        PORTB+0, 3
;HMI_Sorter_(min_sec).c,106 :: 		Lcd_Cmd(0x0C);                                                              // Blink off
	MOVLW      12
	MOVWF      FARG_Lcd_Cmd_out_char+0
	CALL       _Lcd_Cmd+0
;HMI_Sorter_(min_sec).c,107 :: 		Lcd_Cmd(_LCD_CLEAR);
	MOVLW      1
	MOVWF      FARG_Lcd_Cmd_out_char+0
	CALL       _Lcd_Cmd+0
;HMI_Sorter_(min_sec).c,108 :: 		Lcd_Out(1,5,"EMERGENCY");
	MOVLW      1
	MOVWF      FARG_Lcd_Out_row+0
	MOVLW      5
	MOVWF      FARG_Lcd_Out_column+0
	MOVLW      ?lstr1_HMI_Sorter__40min_sec_41+0
	MOVWF      FARG_Lcd_Out_text+0
	CALL       _Lcd_Out+0
;HMI_Sorter_(min_sec).c,109 :: 		ACK_EMS = 1;
	BSF        PORTA+0, 7
;HMI_Sorter_(min_sec).c,110 :: 		while(1);
L_ems_halt0:
	GOTO       L_ems_halt0
;HMI_Sorter_(min_sec).c,111 :: 		}
	RETURN
; end of _ems_halt

_main:

;HMI_Sorter_(min_sec).c,118 :: 		void main() {
;HMI_Sorter_(min_sec).c,119 :: 		CMCON = 0x07;                                                               // disable comparators
	MOVLW      7
	MOVWF      CMCON+0
;HMI_Sorter_(min_sec).c,120 :: 		TRISA = 0x7F;                                                               // 0111 1111 = 0x7F (all input, only RA7 as output)
	MOVLW      127
	MOVWF      TRISA+0
;HMI_Sorter_(min_sec).c,121 :: 		PORTA = 0x00;
	CLRF       PORTA+0
;HMI_Sorter_(min_sec).c,122 :: 		TRISB = 0x00;                                                               // 0000 0000 = 0x00 (whole RB port is output)
	CLRF       TRISB+0
;HMI_Sorter_(min_sec).c,123 :: 		PORTB = 0x00;
	CLRF       PORTB+0
;HMI_Sorter_(min_sec).c,125 :: 		Lcd_Init();
	CALL       _Lcd_Init+0
;HMI_Sorter_(min_sec).c,126 :: 		Lcd_Cmd(0x0C);                                                              // display ON, cursor OFF, Blink OFF
	MOVLW      12
	MOVWF      FARG_Lcd_Cmd_out_char+0
	CALL       _Lcd_Cmd+0
;HMI_Sorter_(min_sec).c,129 :: 		Lcd_Out(1,4,"MURAT-TECH");
	MOVLW      1
	MOVWF      FARG_Lcd_Out_row+0
	MOVLW      4
	MOVWF      FARG_Lcd_Out_column+0
	MOVLW      ?lstr2_HMI_Sorter__40min_sec_41+0
	MOVWF      FARG_Lcd_Out_text+0
	CALL       _Lcd_Out+0
;HMI_Sorter_(min_sec).c,130 :: 		Lcd_Chr(2,6,'S');                                                           // write "SORTER" char to char (to save memory)
	MOVLW      2
	MOVWF      FARG_Lcd_Chr_row+0
	MOVLW      6
	MOVWF      FARG_Lcd_Chr_column+0
	MOVLW      83
	MOVWF      FARG_Lcd_Chr_out_char+0
	CALL       _Lcd_Chr+0
;HMI_Sorter_(min_sec).c,131 :: 		Lcd_Chr_Cp('O');
	MOVLW      79
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
;HMI_Sorter_(min_sec).c,132 :: 		Lcd_Chr_Cp('R');
	MOVLW      82
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
;HMI_Sorter_(min_sec).c,133 :: 		Lcd_Chr_Cp('T');
	MOVLW      84
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
;HMI_Sorter_(min_sec).c,134 :: 		Lcd_Chr_Cp('E');
	MOVLW      69
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
;HMI_Sorter_(min_sec).c,135 :: 		Lcd_Chr_Cp('R');
	MOVLW      82
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
;HMI_Sorter_(min_sec).c,137 :: 		delay_ms(2000);
	MOVLW      11
	MOVWF      R11+0
	MOVLW      38
	MOVWF      R12+0
	MOVLW      93
	MOVWF      R13+0
L_main2:
	DECFSZ     R13+0, 1
	GOTO       L_main2
	DECFSZ     R12+0, 1
	GOTO       L_main2
	DECFSZ     R11+0, 1
	GOTO       L_main2
	NOP
	NOP
;HMI_Sorter_(min_sec).c,138 :: 		pageState = 0;
	CLRF       _pageState+0
;HMI_Sorter_(min_sec).c,141 :: 		boxes = EEPROM_Read(slotA);
	CLRF       FARG_EEPROM_Read_Address+0
	CALL       _EEPROM_Read+0
	MOVF       R0+0, 0
	MOVWF      _boxes+0
;HMI_Sorter_(min_sec).c,142 :: 		sortMin = EEPROM_Read(slotB);
	MOVLW      1
	MOVWF      FARG_EEPROM_Read_Address+0
	CALL       _EEPROM_Read+0
	MOVF       R0+0, 0
	MOVWF      _sortMin+0
;HMI_Sorter_(min_sec).c,143 :: 		sortSec = EEPROM_Read(slotC);
	MOVLW      2
	MOVWF      FARG_EEPROM_Read_Address+0
	CALL       _EEPROM_Read+0
	MOVF       R0+0, 0
	MOVWF      _sortSec+0
;HMI_Sorter_(min_sec).c,144 :: 		sortQty = (EEPROM_Read(slotD + 1) << 8) | EEPROM_Read(slotD);
	MOVLW      4
	MOVWF      FARG_EEPROM_Read_Address+0
	CALL       _EEPROM_Read+0
	MOVF       R0+0, 0
	MOVWF      FLOC__main+1
	CLRF       FLOC__main+0
	MOVLW      3
	MOVWF      FARG_EEPROM_Read_Address+0
	CALL       _EEPROM_Read+0
	MOVF       R0+0, 0
	IORWF      FLOC__main+0, 0
	MOVWF      _sortQty+0
	MOVF       FLOC__main+1, 0
	MOVWF      _sortQty+1
	MOVLW      0
	IORWF      _sortQty+1, 1
;HMI_Sorter_(min_sec).c,145 :: 		jobLimit = EEPROM_Read(slotE);
	MOVLW      5
	MOVWF      FARG_EEPROM_Read_Address+0
	CALL       _EEPROM_Read+0
	MOVF       R0+0, 0
	MOVWF      _jobLimit+0
;HMI_Sorter_(min_sec).c,147 :: 		if(EEPROM_Read(slotKey) != 42){                                             // used only to load defaults (very 1st run after uC flash)
	MOVLW      16
	MOVWF      FARG_EEPROM_Read_Address+0
	CALL       _EEPROM_Read+0
	MOVF       R0+0, 0
	XORLW      42
	BTFSC      STATUS+0, 2
	GOTO       L_main3
;HMI_Sorter_(min_sec).c,148 :: 		boxes = 0; sortMin = 0; sortSec = 3; sortQty = 5; jobLimit = 4;
	CLRF       _boxes+0
	CLRF       _sortMin+0
	MOVLW      3
	MOVWF      _sortSec+0
	MOVLW      5
	MOVWF      _sortQty+0
	MOVLW      0
	MOVWF      _sortQty+1
	MOVLW      4
	MOVWF      _jobLimit+0
;HMI_Sorter_(min_sec).c,149 :: 		}
L_main3:
;HMI_Sorter_(min_sec).c,151 :: 		bkpQty = sortQty;
	MOVF       _sortQty+0, 0
	MOVWF      _bkpQty+0
	MOVF       _sortQty+1, 0
	MOVWF      _bkpQty+1
;HMI_Sorter_(min_sec).c,152 :: 		bkpSortMin = sortMin;
	MOVF       _sortMin+0, 0
	MOVWF      _bkpSortMin+0
;HMI_Sorter_(min_sec).c,153 :: 		bkpSortSec = sortSec;
	MOVF       _sortSec+0, 0
	MOVWF      _bkpSortSec+0
;HMI_Sorter_(min_sec).c,154 :: 		bkpJobLimit = jobLimit;
	MOVF       _jobLimit+0, 0
	MOVWF      _bkpJobLimit+0
;HMI_Sorter_(min_sec).c,155 :: 		refreshUI();
	CALL       _refreshUI+0
;HMI_Sorter_(min_sec).c,157 :: 		while (1) {
L_main4:
;HMI_Sorter_(min_sec).c,158 :: 		CHECK_EMS;                                                              // Check emergency every 50ms (pooling on preprocessor)
	BTFSS      PORTA+0, 6
	GOTO       L_main6
	CALL       _ems_halt+0
L_main6:
;HMI_Sorter_(min_sec).c,160 :: 		if(ENTER || ESC){
	BTFSC      PORTA+0, 2
	GOTO       L__main160
	BTFSC      PORTA+0, 3
	GOTO       L__main160
	GOTO       L_main9
L__main160:
;HMI_Sorter_(min_sec).c,162 :: 		enterFlag = ENTER;
	MOVLW      0
	BTFSC      PORTA+0, 2
	MOVLW      1
	MOVWF      main_enterFlag_L2+0
;HMI_Sorter_(min_sec).c,163 :: 		while(ENTER || ESC);
L_main10:
	BTFSC      PORTA+0, 2
	GOTO       L__main159
	BTFSC      PORTA+0, 3
	GOTO       L__main159
	GOTO       L_main11
L__main159:
	GOTO       L_main10
L_main11:
;HMI_Sorter_(min_sec).c,165 :: 		if(pageState == 0){                                                 // Confirmation page (START?)
	MOVF       _pageState+0, 0
	XORLW      0
	BTFSS      STATUS+0, 2
	GOTO       L_main14
;HMI_Sorter_(min_sec).c,166 :: 		if(enterFlag){
	MOVF       main_enterFlag_L2+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_main15
;HMI_Sorter_(min_sec).c,167 :: 		pageState = 1;
	MOVLW      1
	MOVWF      _pageState+0
;HMI_Sorter_(min_sec).c,169 :: 		if(EEPROM_Read(slotKey) != 42) {
	MOVLW      16
	MOVWF      FARG_EEPROM_Read_Address+0
	CALL       _EEPROM_Read+0
	MOVF       R0+0, 0
	XORLW      42
	BTFSC      STATUS+0, 2
	GOTO       L_main16
;HMI_Sorter_(min_sec).c,170 :: 		EEPROM_Write(slotA, boxes);                              // Save to EEPROM (power loss recovery)
	CLRF       FARG_EEPROM_Write_Address+0
	MOVF       _boxes+0, 0
	MOVWF      FARG_EEPROM_Write_data_+0
	CALL       _EEPROM_Write+0
;HMI_Sorter_(min_sec).c,171 :: 		adj = 4;                                                 // Trick the logic to think just finished adjusting
	MOVLW      4
	MOVWF      _adj+0
;HMI_Sorter_(min_sec).c,172 :: 		pageState = 3;                                           // Force transition to the SAVE block
	MOVLW      3
	MOVWF      _pageState+0
;HMI_Sorter_(min_sec).c,173 :: 		}
L_main16:
;HMI_Sorter_(min_sec).c,174 :: 		}
	GOTO       L_main17
L_main15:
;HMI_Sorter_(min_sec).c,176 :: 		pageState = 2;
	MOVLW      2
	MOVWF      _pageState+0
L_main17:
;HMI_Sorter_(min_sec).c,177 :: 		}
	GOTO       L_main18
L_main14:
;HMI_Sorter_(min_sec).c,178 :: 		else if(pageState == 1){                                            // Home page (RUNNING)
	MOVF       _pageState+0, 0
	XORLW      1
	BTFSS      STATUS+0, 2
	GOTO       L_main19
;HMI_Sorter_(min_sec).c,179 :: 		if(!enterFlag){
	MOVF       main_enterFlag_L2+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_main20
;HMI_Sorter_(min_sec).c,180 :: 		pageState = 2;
	MOVLW      2
	MOVWF      _pageState+0
;HMI_Sorter_(min_sec).c,181 :: 		adj = 1;
	MOVLW      1
	MOVWF      _adj+0
;HMI_Sorter_(min_sec).c,182 :: 		MOTOR_RUN = 0;
	BCF        PORTB+0, 2
;HMI_Sorter_(min_sec).c,183 :: 		}
L_main20:
;HMI_Sorter_(min_sec).c,184 :: 		}
	GOTO       L_main21
L_main19:
;HMI_Sorter_(min_sec).c,185 :: 		else if(pageState == 2){                                            // Settings page
	MOVF       _pageState+0, 0
	XORLW      2
	BTFSS      STATUS+0, 2
	GOTO       L_main22
;HMI_Sorter_(min_sec).c,186 :: 		if(enterFlag){
	MOVF       main_enterFlag_L2+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_main23
;HMI_Sorter_(min_sec).c,187 :: 		adj++;
	INCF       _adj+0, 1
;HMI_Sorter_(min_sec).c,188 :: 		if(adj > 4)
	MOVF       _adj+0, 0
	SUBLW      4
	BTFSC      STATUS+0, 0
	GOTO       L_main24
;HMI_Sorter_(min_sec).c,189 :: 		pageState = 3;
	MOVLW      3
	MOVWF      _pageState+0
L_main24:
;HMI_Sorter_(min_sec).c,190 :: 		}
	GOTO       L_main25
L_main23:
;HMI_Sorter_(min_sec).c,192 :: 		pageState = 3;
	MOVLW      3
	MOVWF      _pageState+0
L_main25:
;HMI_Sorter_(min_sec).c,193 :: 		}
	GOTO       L_main26
L_main22:
;HMI_Sorter_(min_sec).c,194 :: 		else if(pageState == 3){                                            // Confirmation page (SAVE?)
	MOVF       _pageState+0, 0
	XORLW      3
	BTFSS      STATUS+0, 2
	GOTO       L_main27
;HMI_Sorter_(min_sec).c,195 :: 		if(enterFlag){
	MOVF       main_enterFlag_L2+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_main28
;HMI_Sorter_(min_sec).c,197 :: 		EEPROM_Write(slotB, sortMin);
	MOVLW      1
	MOVWF      FARG_EEPROM_Write_Address+0
	MOVF       _sortMin+0, 0
	MOVWF      FARG_EEPROM_Write_data_+0
	CALL       _EEPROM_Write+0
;HMI_Sorter_(min_sec).c,198 :: 		EEPROM_Write(slotC, sortSec);
	MOVLW      2
	MOVWF      FARG_EEPROM_Write_Address+0
	MOVF       _sortSec+0, 0
	MOVWF      FARG_EEPROM_Write_data_+0
	CALL       _EEPROM_Write+0
;HMI_Sorter_(min_sec).c,199 :: 		EEPROM_Write(slotE, jobLimit);
	MOVLW      5
	MOVWF      FARG_EEPROM_Write_Address+0
	MOVF       _jobLimit+0, 0
	MOVWF      FARG_EEPROM_Write_data_+0
	CALL       _EEPROM_Write+0
;HMI_Sorter_(min_sec).c,200 :: 		EEPROM_Write(slotKey, 42);                                  // Mark EEPROM as initialized
	MOVLW      16
	MOVWF      FARG_EEPROM_Write_Address+0
	MOVLW      42
	MOVWF      FARG_EEPROM_Write_data_+0
	CALL       _EEPROM_Write+0
;HMI_Sorter_(min_sec).c,203 :: 		EEPROM_Write(slotD, (char)sortQty);
	MOVLW      3
	MOVWF      FARG_EEPROM_Write_Address+0
	MOVF       _sortQty+0, 0
	MOVWF      FARG_EEPROM_Write_data_+0
	CALL       _EEPROM_Write+0
;HMI_Sorter_(min_sec).c,204 :: 		delay_ms(20);
	MOVLW      26
	MOVWF      R12+0
	MOVLW      248
	MOVWF      R13+0
L_main29:
	DECFSZ     R13+0, 1
	GOTO       L_main29
	DECFSZ     R12+0, 1
	GOTO       L_main29
	NOP
;HMI_Sorter_(min_sec).c,205 :: 		EEPROM_Write(slotD + 1, (char)(sortQty >> 8));
	MOVLW      4
	MOVWF      FARG_EEPROM_Write_Address+0
	MOVF       _sortQty+1, 0
	MOVWF      R0+0
	CLRF       R0+1
	MOVF       R0+0, 0
	MOVWF      FARG_EEPROM_Write_data_+0
	CALL       _EEPROM_Write+0
;HMI_Sorter_(min_sec).c,206 :: 		delay_ms(20);
	MOVLW      26
	MOVWF      R12+0
	MOVLW      248
	MOVWF      R13+0
L_main30:
	DECFSZ     R13+0, 1
	GOTO       L_main30
	DECFSZ     R12+0, 1
	GOTO       L_main30
	NOP
;HMI_Sorter_(min_sec).c,208 :: 		if(sortQty != bkpQty || jobLimit != bkpJobLimit){           // reset counters only if quantities are changed (not the sort time)
	MOVF       _sortQty+1, 0
	XORWF      _bkpQty+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__main174
	MOVF       _bkpQty+0, 0
	XORWF      _sortQty+0, 0
L__main174:
	BTFSS      STATUS+0, 2
	GOTO       L__main158
	MOVF       _jobLimit+0, 0
	XORWF      _bkpJobLimit+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L__main158
	GOTO       L_main33
L__main158:
;HMI_Sorter_(min_sec).c,209 :: 		boxes = 0;
	CLRF       _boxes+0
;HMI_Sorter_(min_sec).c,210 :: 		obj = 0;
	CLRF       _obj+0
	CLRF       _obj+1
;HMI_Sorter_(min_sec).c,211 :: 		}
L_main33:
;HMI_Sorter_(min_sec).c,213 :: 		bkpQty = sortQty;                                           // update reference data if saved
	MOVF       _sortQty+0, 0
	MOVWF      _bkpQty+0
	MOVF       _sortQty+1, 0
	MOVWF      _bkpQty+1
;HMI_Sorter_(min_sec).c,214 :: 		bkpJobLimit = jobLimit;
	MOVF       _jobLimit+0, 0
	MOVWF      _bkpJobLimit+0
;HMI_Sorter_(min_sec).c,215 :: 		bkpSortMin = sortMin;
	MOVF       _sortMin+0, 0
	MOVWF      _bkpSortMin+0
;HMI_Sorter_(min_sec).c,216 :: 		bkpSortSec = sortSec;
	MOVF       _sortSec+0, 0
	MOVWF      _bkpSortSec+0
;HMI_Sorter_(min_sec).c,218 :: 		ACK_EMS = 1;
	BSF        PORTA+0, 7
;HMI_Sorter_(min_sec).c,219 :: 		for(obj=0; obj<10000; obj++);                               // Acknowledge blink
	CLRF       _obj+0
	CLRF       _obj+1
L_main34:
	MOVLW      39
	SUBWF      _obj+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__main175
	MOVLW      16
	SUBWF      _obj+0, 0
L__main175:
	BTFSC      STATUS+0, 0
	GOTO       L_main35
	INCF       _obj+0, 1
	BTFSC      STATUS+0, 2
	INCF       _obj+1, 1
	GOTO       L_main34
L_main35:
;HMI_Sorter_(min_sec).c,220 :: 		ACK_EMS = 0;
	BCF        PORTA+0, 7
;HMI_Sorter_(min_sec).c,221 :: 		obj = 0;
	CLRF       _obj+0
	CLRF       _obj+1
;HMI_Sorter_(min_sec).c,223 :: 		}
	GOTO       L_main37
L_main28:
;HMI_Sorter_(min_sec).c,225 :: 		sortQty = bkpQty;                                           // Recover data if new entries are not saved
	MOVF       _bkpQty+0, 0
	MOVWF      _sortQty+0
	MOVF       _bkpQty+1, 0
	MOVWF      _sortQty+1
;HMI_Sorter_(min_sec).c,226 :: 		sortMin = bkpSortMin;
	MOVF       _bkpSortMin+0, 0
	MOVWF      _sortMin+0
;HMI_Sorter_(min_sec).c,227 :: 		sortSec = bkpSortSec;
	MOVF       _bkpSortSec+0, 0
	MOVWF      _sortSec+0
;HMI_Sorter_(min_sec).c,228 :: 		jobLimit = bkpJobLimit;
	MOVF       _bkpJobLimit+0, 0
	MOVWF      _jobLimit+0
;HMI_Sorter_(min_sec).c,229 :: 		adj = 0;
	CLRF       _adj+0
;HMI_Sorter_(min_sec).c,230 :: 		}
L_main37:
;HMI_Sorter_(min_sec).c,231 :: 		pageState = 0;
	CLRF       _pageState+0
;HMI_Sorter_(min_sec).c,232 :: 		}
L_main27:
L_main26:
L_main21:
L_main18:
;HMI_Sorter_(min_sec).c,233 :: 		refreshUI();                                                        // Only update screen on button press
	CALL       _refreshUI+0
;HMI_Sorter_(min_sec).c,235 :: 		}
L_main9:
;HMI_Sorter_(min_sec).c,237 :: 		if(pageState == 1){                                                     // Make sure boxes qty is not bigger than job size
	MOVF       _pageState+0, 0
	XORLW      1
	BTFSS      STATUS+0, 2
	GOTO       L_main38
;HMI_Sorter_(min_sec).c,238 :: 		if(boxes >= jobLimit)
	MOVF       _jobLimit+0, 0
	SUBWF      _boxes+0, 0
	BTFSS      STATUS+0, 0
	GOTO       L_main39
;HMI_Sorter_(min_sec).c,239 :: 		boxes = 0;
	CLRF       _boxes+0
	GOTO       L_main40
L_main39:
;HMI_Sorter_(min_sec).c,241 :: 		MOTOR_RUN = 1;
	BSF        PORTB+0, 2
;HMI_Sorter_(min_sec).c,242 :: 		objectCount();
	CALL       _objectCount+0
;HMI_Sorter_(min_sec).c,243 :: 		}
L_main40:
;HMI_Sorter_(min_sec).c,244 :: 		}else if(pageState == 2){                                               // Update settings according with limits
	GOTO       L_main41
L_main38:
	MOVF       _pageState+0, 0
	XORLW      2
	BTFSS      STATUS+0, 2
	GOTO       L_main42
;HMI_Sorter_(min_sec).c,245 :: 		if(INC || DEC){
	BTFSC      PORTA+0, 0
	GOTO       L__main157
	BTFSC      PORTA+0, 1
	GOTO       L__main157
	GOTO       L_main45
L__main157:
;HMI_Sorter_(min_sec).c,247 :: 		if(INC)
	BTFSS      PORTA+0, 0
	GOTO       L_main46
;HMI_Sorter_(min_sec).c,248 :: 		d = 1;
	MOVLW      1
	MOVWF      main_d_L3+0
	GOTO       L_main47
L_main46:
;HMI_Sorter_(min_sec).c,250 :: 		d = -1;
	MOVLW      255
	MOVWF      main_d_L3+0
L_main47:
;HMI_Sorter_(min_sec).c,252 :: 		if(adj == 1){
	MOVF       _adj+0, 0
	XORLW      1
	BTFSS      STATUS+0, 2
	GOTO       L_main48
;HMI_Sorter_(min_sec).c,253 :: 		sortMin += d;
	MOVF       main_d_L3+0, 0
	ADDWF      _sortMin+0, 0
	MOVWF      R1+0
	MOVF       R1+0, 0
	MOVWF      _sortMin+0
;HMI_Sorter_(min_sec).c,254 :: 		if(sortMin > 1)
	MOVF       R1+0, 0
	SUBLW      1
	BTFSC      STATUS+0, 0
	GOTO       L_main49
;HMI_Sorter_(min_sec).c,255 :: 		sortMin = 0;
	CLRF       _sortMin+0
L_main49:
;HMI_Sorter_(min_sec).c,256 :: 		if(sortMin < 0)
	MOVLW      0
	SUBWF      _sortMin+0, 0
	BTFSC      STATUS+0, 0
	GOTO       L_main50
;HMI_Sorter_(min_sec).c,257 :: 		sortMin = 1;
	MOVLW      1
	MOVWF      _sortMin+0
L_main50:
;HMI_Sorter_(min_sec).c,258 :: 		}
	GOTO       L_main51
L_main48:
;HMI_Sorter_(min_sec).c,259 :: 		else if(adj == 2){
	MOVF       _adj+0, 0
	XORLW      2
	BTFSS      STATUS+0, 2
	GOTO       L_main52
;HMI_Sorter_(min_sec).c,260 :: 		sortSec += d;
	MOVF       main_d_L3+0, 0
	ADDWF      _sortSec+0, 0
	MOVWF      R1+0
	MOVF       R1+0, 0
	MOVWF      _sortSec+0
;HMI_Sorter_(min_sec).c,261 :: 		if(sortSec > 59)
	MOVF       R1+0, 0
	SUBLW      59
	BTFSC      STATUS+0, 0
	GOTO       L_main53
;HMI_Sorter_(min_sec).c,262 :: 		sortSec = 0;
	CLRF       _sortSec+0
L_main53:
;HMI_Sorter_(min_sec).c,263 :: 		if(sortSec < 0)
	MOVLW      0
	SUBWF      _sortSec+0, 0
	BTFSC      STATUS+0, 0
	GOTO       L_main54
;HMI_Sorter_(min_sec).c,264 :: 		sortSec = 59;
	MOVLW      59
	MOVWF      _sortSec+0
L_main54:
;HMI_Sorter_(min_sec).c,265 :: 		}
	GOTO       L_main55
L_main52:
;HMI_Sorter_(min_sec).c,266 :: 		else if(adj == 3){
	MOVF       _adj+0, 0
	XORLW      3
	BTFSS      STATUS+0, 2
	GOTO       L_main56
;HMI_Sorter_(min_sec).c,267 :: 		sortQty += d;
	MOVF       main_d_L3+0, 0
	ADDWF      _sortQty+0, 0
	MOVWF      R1+0
	MOVF       _sortQty+1, 0
	BTFSC      STATUS+0, 0
	ADDLW      1
	MOVWF      R1+1
	MOVLW      0
	BTFSC      main_d_L3+0, 7
	MOVLW      255
	ADDWF      R1+1, 1
	MOVF       R1+0, 0
	MOVWF      _sortQty+0
	MOVF       R1+1, 0
	MOVWF      _sortQty+1
;HMI_Sorter_(min_sec).c,268 :: 		if(sortQty > 999)
	MOVF       R1+1, 0
	SUBLW      3
	BTFSS      STATUS+0, 2
	GOTO       L__main176
	MOVF       R1+0, 0
	SUBLW      231
L__main176:
	BTFSC      STATUS+0, 0
	GOTO       L_main57
;HMI_Sorter_(min_sec).c,269 :: 		sortQty = 1;
	MOVLW      1
	MOVWF      _sortQty+0
	MOVLW      0
	MOVWF      _sortQty+1
L_main57:
;HMI_Sorter_(min_sec).c,270 :: 		if(sortQty < 1)
	MOVLW      0
	SUBWF      _sortQty+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__main177
	MOVLW      1
	SUBWF      _sortQty+0, 0
L__main177:
	BTFSC      STATUS+0, 0
	GOTO       L_main58
;HMI_Sorter_(min_sec).c,271 :: 		sortQty = 999;
	MOVLW      231
	MOVWF      _sortQty+0
	MOVLW      3
	MOVWF      _sortQty+1
L_main58:
;HMI_Sorter_(min_sec).c,272 :: 		}
	GOTO       L_main59
L_main56:
;HMI_Sorter_(min_sec).c,273 :: 		else if(adj == 4){
	MOVF       _adj+0, 0
	XORLW      4
	BTFSS      STATUS+0, 2
	GOTO       L_main60
;HMI_Sorter_(min_sec).c,274 :: 		jobLimit += d;
	MOVF       main_d_L3+0, 0
	ADDWF      _jobLimit+0, 0
	MOVWF      R1+0
	MOVF       R1+0, 0
	MOVWF      _jobLimit+0
;HMI_Sorter_(min_sec).c,275 :: 		if(jobLimit > 99)
	MOVF       R1+0, 0
	SUBLW      99
	BTFSC      STATUS+0, 0
	GOTO       L_main61
;HMI_Sorter_(min_sec).c,276 :: 		jobLimit = 1;
	MOVLW      1
	MOVWF      _jobLimit+0
L_main61:
;HMI_Sorter_(min_sec).c,277 :: 		if(jobLimit < 1)
	MOVLW      1
	SUBWF      _jobLimit+0, 0
	BTFSC      STATUS+0, 0
	GOTO       L_main62
;HMI_Sorter_(min_sec).c,278 :: 		jobLimit = 99;
	MOVLW      99
	MOVWF      _jobLimit+0
L_main62:
;HMI_Sorter_(min_sec).c,279 :: 		}
L_main60:
L_main59:
L_main55:
L_main51:
;HMI_Sorter_(min_sec).c,280 :: 		refreshUI();
	CALL       _refreshUI+0
;HMI_Sorter_(min_sec).c,281 :: 		while(INC || DEC);
L_main63:
	BTFSC      PORTA+0, 0
	GOTO       L__main156
	BTFSC      PORTA+0, 1
	GOTO       L__main156
	GOTO       L_main64
L__main156:
	GOTO       L_main63
L_main64:
;HMI_Sorter_(min_sec).c,282 :: 		}
L_main45:
;HMI_Sorter_(min_sec).c,283 :: 		}
L_main42:
L_main41:
;HMI_Sorter_(min_sec).c,284 :: 		}
	GOTO       L_main4
;HMI_Sorter_(min_sec).c,285 :: 		}
	GOTO       $+0
; end of _main

_refreshUI:

;HMI_Sorter_(min_sec).c,290 :: 		void refreshUI() {
;HMI_Sorter_(min_sec).c,293 :: 		if (pageState != lastPage) {
	MOVF       _pageState+0, 0
	XORWF      _lastPage+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_refreshUI67
;HMI_Sorter_(min_sec).c,294 :: 		Lcd_Cmd(0x0C);                                                          // Blink off
	MOVLW      12
	MOVWF      FARG_Lcd_Cmd_out_char+0
	CALL       _Lcd_Cmd+0
;HMI_Sorter_(min_sec).c,295 :: 		Lcd_Cmd(_LCD_CLEAR);
	MOVLW      1
	MOVWF      FARG_Lcd_Cmd_out_char+0
	CALL       _Lcd_Cmd+0
;HMI_Sorter_(min_sec).c,297 :: 		if (pageState == 0 || pageState == 3) {                                 // Pages 0 and 3
	MOVF       _pageState+0, 0
	XORLW      0
	BTFSC      STATUS+0, 2
	GOTO       L__refreshUI161
	MOVF       _pageState+0, 0
	XORLW      3
	BTFSC      STATUS+0, 2
	GOTO       L__refreshUI161
	GOTO       L_refreshUI70
L__refreshUI161:
;HMI_Sorter_(min_sec).c,298 :: 		if (pageState == 0)
	MOVF       _pageState+0, 0
	XORLW      0
	BTFSS      STATUS+0, 2
	GOTO       L_refreshUI71
;HMI_Sorter_(min_sec).c,299 :: 		Lcd_Out(1,6,"START?");
	MOVLW      1
	MOVWF      FARG_Lcd_Out_row+0
	MOVLW      6
	MOVWF      FARG_Lcd_Out_column+0
	MOVLW      ?lstr3_HMI_Sorter__40min_sec_41+0
	MOVWF      FARG_Lcd_Out_text+0
	CALL       _Lcd_Out+0
	GOTO       L_refreshUI72
L_refreshUI71:
;HMI_Sorter_(min_sec).c,302 :: 		Lcd_Out(1,6,"SAVE?");
	MOVLW      1
	MOVWF      FARG_Lcd_Out_row+0
	MOVLW      6
	MOVWF      FARG_Lcd_Out_column+0
	MOVLW      ?lstr4_HMI_Sorter__40min_sec_41+0
	MOVWF      FARG_Lcd_Out_text+0
	CALL       _Lcd_Out+0
L_refreshUI72:
;HMI_Sorter_(min_sec).c,305 :: 		Lcd_Out(2,5,"ENT/ESC");
	MOVLW      2
	MOVWF      FARG_Lcd_Out_row+0
	MOVLW      5
	MOVWF      FARG_Lcd_Out_column+0
	MOVLW      ?lstr5_HMI_Sorter__40min_sec_41+0
	MOVWF      FARG_Lcd_Out_text+0
	CALL       _Lcd_Out+0
;HMI_Sorter_(min_sec).c,307 :: 		}
	GOTO       L_refreshUI73
L_refreshUI70:
;HMI_Sorter_(min_sec).c,309 :: 		if (pageState == 1)
	MOVF       _pageState+0, 0
	XORLW      1
	BTFSS      STATUS+0, 2
	GOTO       L_refreshUI74
;HMI_Sorter_(min_sec).c,310 :: 		Lcd_Out(1,6,"RUNNING");
	MOVLW      1
	MOVWF      FARG_Lcd_Out_row+0
	MOVLW      6
	MOVWF      FARG_Lcd_Out_column+0
	MOVLW      ?lstr6_HMI_Sorter__40min_sec_41+0
	MOVWF      FARG_Lcd_Out_text+0
	CALL       _Lcd_Out+0
	GOTO       L_refreshUI75
L_refreshUI74:
;HMI_Sorter_(min_sec).c,312 :: 		Lcd_Out(1,3,"Sort:   m   s");
	MOVLW      1
	MOVWF      FARG_Lcd_Out_row+0
	MOVLW      3
	MOVWF      FARG_Lcd_Out_column+0
	MOVLW      ?lstr7_HMI_Sorter__40min_sec_41+0
	MOVWF      FARG_Lcd_Out_text+0
	CALL       _Lcd_Out+0
L_refreshUI75:
;HMI_Sorter_(min_sec).c,315 :: 		Lcd_Out(2,3,"Pc:    Box:");
	MOVLW      2
	MOVWF      FARG_Lcd_Out_row+0
	MOVLW      3
	MOVWF      FARG_Lcd_Out_column+0
	MOVLW      ?lstr8_HMI_Sorter__40min_sec_41+0
	MOVWF      FARG_Lcd_Out_text+0
	CALL       _Lcd_Out+0
;HMI_Sorter_(min_sec).c,316 :: 		}
L_refreshUI73:
;HMI_Sorter_(min_sec).c,317 :: 		lastPage = pageState;
	MOVF       _pageState+0, 0
	MOVWF      _lastPage+0
;HMI_Sorter_(min_sec).c,318 :: 		}
L_refreshUI67:
;HMI_Sorter_(min_sec).c,321 :: 		if (pageState == 1) {
	MOVF       _pageState+0, 0
	XORLW      1
	BTFSS      STATUS+0, 2
	GOTO       L_refreshUI76
;HMI_Sorter_(min_sec).c,322 :: 		disp_num(obj, 2, 6, VAL_CEN);
	MOVF       _obj+0, 0
	MOVWF      FARG_disp_num_num+0
	MOVF       _obj+1, 0
	MOVWF      FARG_disp_num_num+1
	MOVLW      2
	MOVWF      FARG_disp_num_row+0
	MOVLW      6
	MOVWF      FARG_disp_num_col+0
	MOVLW      2
	MOVWF      FARG_disp_num_range+0
	CALL       _disp_num+0
;HMI_Sorter_(min_sec).c,323 :: 		disp_num(boxes, 2, 14, VAL_DEZ);
	MOVF       _boxes+0, 0
	MOVWF      FARG_disp_num_num+0
	CLRF       FARG_disp_num_num+1
	MOVLW      2
	MOVWF      FARG_disp_num_row+0
	MOVLW      14
	MOVWF      FARG_disp_num_col+0
	MOVLW      1
	MOVWF      FARG_disp_num_range+0
	CALL       _disp_num+0
;HMI_Sorter_(min_sec).c,324 :: 		}
	GOTO       L_refreshUI77
L_refreshUI76:
;HMI_Sorter_(min_sec).c,325 :: 		else if (pageState == 2) {
	MOVF       _pageState+0, 0
	XORLW      2
	BTFSS      STATUS+0, 2
	GOTO       L_refreshUI78
;HMI_Sorter_(min_sec).c,326 :: 		disp_num(sortMin, 1, 10, VAL_UNI);
	MOVF       _sortMin+0, 0
	MOVWF      FARG_disp_num_num+0
	CLRF       FARG_disp_num_num+1
	MOVLW      1
	MOVWF      FARG_disp_num_row+0
	MOVLW      10
	MOVWF      FARG_disp_num_col+0
	CLRF       FARG_disp_num_range+0
	CALL       _disp_num+0
;HMI_Sorter_(min_sec).c,327 :: 		disp_num(sortSec, 1, 13, VAL_DEZ);
	MOVF       _sortSec+0, 0
	MOVWF      FARG_disp_num_num+0
	CLRF       FARG_disp_num_num+1
	MOVLW      1
	MOVWF      FARG_disp_num_row+0
	MOVLW      13
	MOVWF      FARG_disp_num_col+0
	MOVLW      1
	MOVWF      FARG_disp_num_range+0
	CALL       _disp_num+0
;HMI_Sorter_(min_sec).c,328 :: 		disp_num(sortQty, 2, 6, VAL_CEN);
	MOVF       _sortQty+0, 0
	MOVWF      FARG_disp_num_num+0
	MOVF       _sortQty+1, 0
	MOVWF      FARG_disp_num_num+1
	MOVLW      2
	MOVWF      FARG_disp_num_row+0
	MOVLW      6
	MOVWF      FARG_disp_num_col+0
	MOVLW      2
	MOVWF      FARG_disp_num_range+0
	CALL       _disp_num+0
;HMI_Sorter_(min_sec).c,329 :: 		disp_num(jobLimit, 2, 14, VAL_DEZ);
	MOVF       _jobLimit+0, 0
	MOVWF      FARG_disp_num_num+0
	CLRF       FARG_disp_num_num+1
	MOVLW      2
	MOVWF      FARG_disp_num_row+0
	MOVLW      14
	MOVWF      FARG_disp_num_col+0
	MOVLW      1
	MOVWF      FARG_disp_num_range+0
	CALL       _disp_num+0
;HMI_Sorter_(min_sec).c,332 :: 		if(adj == 1)
	MOVF       _adj+0, 0
	XORLW      1
	BTFSS      STATUS+0, 2
	GOTO       L_refreshUI79
;HMI_Sorter_(min_sec).c,333 :: 		disp_blink(1, 9);                                                     // Blink over minutes
	MOVLW      1
	MOVWF      FARG_disp_blink_row+0
	MOVLW      9
	MOVWF      FARG_disp_blink_col+0
	CALL       _disp_blink+0
L_refreshUI79:
;HMI_Sorter_(min_sec).c,334 :: 		if(adj == 2)
	MOVF       _adj+0, 0
	XORLW      2
	BTFSS      STATUS+0, 2
	GOTO       L_refreshUI80
;HMI_Sorter_(min_sec).c,335 :: 		disp_blink(1, 13);                                                    // Blink over seconds
	MOVLW      1
	MOVWF      FARG_disp_blink_row+0
	MOVLW      13
	MOVWF      FARG_disp_blink_col+0
	CALL       _disp_blink+0
L_refreshUI80:
;HMI_Sorter_(min_sec).c,336 :: 		if(adj == 3)
	MOVF       _adj+0, 0
	XORLW      3
	BTFSS      STATUS+0, 2
	GOTO       L_refreshUI81
;HMI_Sorter_(min_sec).c,337 :: 		disp_blink(2, 7);                                                     // Blink over pieces (quantity)
	MOVLW      2
	MOVWF      FARG_disp_blink_row+0
	MOVLW      7
	MOVWF      FARG_disp_blink_col+0
	CALL       _disp_blink+0
L_refreshUI81:
;HMI_Sorter_(min_sec).c,338 :: 		if(adj == 4)
	MOVF       _adj+0, 0
	XORLW      4
	BTFSS      STATUS+0, 2
	GOTO       L_refreshUI82
;HMI_Sorter_(min_sec).c,339 :: 		disp_blink(2, 14);                                                    // Blink over boxes (job size)
	MOVLW      2
	MOVWF      FARG_disp_blink_row+0
	MOVLW      14
	MOVWF      FARG_disp_blink_col+0
	CALL       _disp_blink+0
L_refreshUI82:
;HMI_Sorter_(min_sec).c,340 :: 		}
L_refreshUI78:
L_refreshUI77:
;HMI_Sorter_(min_sec).c,341 :: 		}
	RETURN
; end of _refreshUI

_objectCount:

;HMI_Sorter_(min_sec).c,346 :: 		void objectCount() {
;HMI_Sorter_(min_sec).c,348 :: 		objTick++;
	INCF       _objTick+0, 1
	BTFSC      STATUS+0, 2
	INCF       _objTick+1, 1
;HMI_Sorter_(min_sec).c,350 :: 		if(objTick >= ONE_SECOND){                                                  // Aprox 1s time base (empiric data)
	MOVLW      71
	SUBWF      _objTick+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__objectCount178
	MOVLW      159
	SUBWF      _objTick+0, 0
L__objectCount178:
	BTFSS      STATUS+0, 0
	GOTO       L_objectCount83
;HMI_Sorter_(min_sec).c,351 :: 		objTick = 0;
	CLRF       _objTick+0
	CLRF       _objTick+1
;HMI_Sorter_(min_sec).c,352 :: 		objTimeOut++;
	INCF       _objTimeOut+0, 1
;HMI_Sorter_(min_sec).c,353 :: 		if(objTimeOut >= 30){                                                    // If no object in 30s (or object stuck), stop & throw error
	MOVLW      30
	SUBWF      _objTimeOut+0, 0
	BTFSS      STATUS+0, 0
	GOTO       L_objectCount84
;HMI_Sorter_(min_sec).c,354 :: 		while(1){
L_objectCount85:
;HMI_Sorter_(min_sec).c,355 :: 		Lcd_Out(1,4,"OBJ TIMEOUT");
	MOVLW      1
	MOVWF      FARG_Lcd_Out_row+0
	MOVLW      4
	MOVWF      FARG_Lcd_Out_column+0
	MOVLW      ?lstr9_HMI_Sorter__40min_sec_41+0
	MOVWF      FARG_Lcd_Out_text+0
	CALL       _Lcd_Out+0
;HMI_Sorter_(min_sec).c,356 :: 		MOTOR_RUN = 0;
	BCF        PORTB+0, 2
;HMI_Sorter_(min_sec).c,357 :: 		ACK_EMS = 1;
	BSF        PORTA+0, 7
;HMI_Sorter_(min_sec).c,358 :: 		}
	GOTO       L_objectCount85
;HMI_Sorter_(min_sec).c,359 :: 		}
L_objectCount84:
;HMI_Sorter_(min_sec).c,360 :: 		}
L_objectCount83:
;HMI_Sorter_(min_sec).c,362 :: 		if(SENSOR)objFlag = 1;
	BTFSS      PORTA+0, 4
	GOTO       L_objectCount87
	MOVLW      1
	MOVWF      objectCount_objFlag_L0+0
L_objectCount87:
;HMI_Sorter_(min_sec).c,364 :: 		if (!SENSOR && objFlag) {
	BTFSC      PORTA+0, 4
	GOTO       L_objectCount90
	MOVF       objectCount_objFlag_L0+0, 0
	BTFSC      STATUS+0, 2
	GOTO       L_objectCount90
L__objectCount163:
;HMI_Sorter_(min_sec).c,365 :: 		objTick = 0;
	CLRF       _objTick+0
	CLRF       _objTick+1
;HMI_Sorter_(min_sec).c,366 :: 		objTimeOut = 0;
	CLRF       _objTimeOut+0
;HMI_Sorter_(min_sec).c,367 :: 		obj++;
	INCF       _obj+0, 1
	BTFSC      STATUS+0, 2
	INCF       _obj+1, 1
;HMI_Sorter_(min_sec).c,368 :: 		refreshUI();                                                            // Update Pc count on screen
	CALL       _refreshUI+0
;HMI_Sorter_(min_sec).c,370 :: 		if (obj >= sortQty) {
	MOVF       _sortQty+1, 0
	SUBWF      _obj+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__objectCount179
	MOVF       _sortQty+0, 0
	SUBWF      _obj+0, 0
L__objectCount179:
	BTFSS      STATUS+0, 0
	GOTO       L_objectCount91
;HMI_Sorter_(min_sec).c,371 :: 		MOTOR_RUN = 0;
	BCF        PORTB+0, 2
;HMI_Sorter_(min_sec).c,372 :: 		SORT_OUT = 1;
	BSF        PORTB+0, 3
;HMI_Sorter_(min_sec).c,373 :: 		Lcd_Out(1,5,"SORTING..");
	MOVLW      1
	MOVWF      FARG_Lcd_Out_row+0
	MOVLW      5
	MOVWF      FARG_Lcd_Out_column+0
	MOVLW      ?lstr10_HMI_Sorter__40min_sec_41+0
	MOVWF      FARG_Lcd_Out_text+0
	CALL       _Lcd_Out+0
;HMI_Sorter_(min_sec).c,376 :: 		totalSortSeconds =  ((sortMin << 6) - (sortMin << 2)) + sortSec;    // sortMin(64 -4)--> sortMin = 60. Same as(sortMin*60) but shift and sub op are memory efficient
	MOVLW      6
	MOVWF      R0+0
	MOVF       _sortMin+0, 0
	MOVWF      _totalSortSeconds+0
	MOVF       R0+0, 0
L__objectCount180:
	BTFSC      STATUS+0, 2
	GOTO       L__objectCount181
	RLF        _totalSortSeconds+0, 1
	BCF        _totalSortSeconds+0, 0
	ADDLW      255
	GOTO       L__objectCount180
L__objectCount181:
	MOVF       _sortMin+0, 0
	MOVWF      R0+0
	RLF        R0+0, 1
	BCF        R0+0, 0
	RLF        R0+0, 1
	BCF        R0+0, 0
	MOVF       R0+0, 0
	SUBWF      _totalSortSeconds+0, 1
	MOVF       _sortSec+0, 0
	ADDWF      _totalSortSeconds+0, 1
;HMI_Sorter_(min_sec).c,378 :: 		for(bkpSortSec = 0; bkpSortSec < totalSortSeconds; bkpSortSec++) {
	CLRF       _bkpSortSec+0
L_objectCount92:
	MOVF       _totalSortSeconds+0, 0
	SUBWF      _bkpSortSec+0, 0
	BTFSC      STATUS+0, 0
	GOTO       L_objectCount93
;HMI_Sorter_(min_sec).c,380 :: 		for(obj = 0; obj < 20; obj++) {
	CLRF       _obj+0
	CLRF       _obj+1
L_objectCount95:
	MOVLW      0
	SUBWF      _obj+1, 0
	BTFSS      STATUS+0, 2
	GOTO       L__objectCount182
	MOVLW      20
	SUBWF      _obj+0, 0
L__objectCount182:
	BTFSC      STATUS+0, 0
	GOTO       L_objectCount96
;HMI_Sorter_(min_sec).c,381 :: 		CHECK_EMS;                                                  // Check the emergency state every 50ms even during sorting time
	BTFSS      PORTA+0, 6
	GOTO       L_objectCount98
	CALL       _ems_halt+0
L_objectCount98:
;HMI_Sorter_(min_sec).c,382 :: 		delay_ms(50);
	MOVLW      65
	MOVWF      R12+0
	MOVLW      238
	MOVWF      R13+0
L_objectCount99:
	DECFSZ     R13+0, 1
	GOTO       L_objectCount99
	DECFSZ     R12+0, 1
	GOTO       L_objectCount99
	NOP
;HMI_Sorter_(min_sec).c,380 :: 		for(obj = 0; obj < 20; obj++) {
	INCF       _obj+0, 1
	BTFSC      STATUS+0, 2
	INCF       _obj+1, 1
;HMI_Sorter_(min_sec).c,383 :: 		}
	GOTO       L_objectCount95
L_objectCount96:
;HMI_Sorter_(min_sec).c,378 :: 		for(bkpSortSec = 0; bkpSortSec < totalSortSeconds; bkpSortSec++) {
	INCF       _bkpSortSec+0, 1
;HMI_Sorter_(min_sec).c,384 :: 		}
	GOTO       L_objectCount92
L_objectCount93:
;HMI_Sorter_(min_sec).c,386 :: 		SORT_OUT = 0;
	BCF        PORTB+0, 3
;HMI_Sorter_(min_sec).c,387 :: 		obj = 0;
	CLRF       _obj+0
	CLRF       _obj+1
;HMI_Sorter_(min_sec).c,388 :: 		boxes++;
	INCF       _boxes+0, 1
;HMI_Sorter_(min_sec).c,389 :: 		EEPROM_Write(slotA, boxes);                                         // Save to EEPROM (power loss recovery)
	CLRF       FARG_EEPROM_Write_Address+0
	MOVF       _boxes+0, 0
	MOVWF      FARG_EEPROM_Write_data_+0
	CALL       _EEPROM_Write+0
;HMI_Sorter_(min_sec).c,391 :: 		if (jobLimit > 0 && boxes >= jobLimit) {                            // Check the end of job
	MOVF       _jobLimit+0, 0
	SUBLW      0
	BTFSC      STATUS+0, 0
	GOTO       L_objectCount102
	MOVF       _jobLimit+0, 0
	SUBWF      _boxes+0, 0
	BTFSS      STATUS+0, 0
	GOTO       L_objectCount102
L__objectCount162:
;HMI_Sorter_(min_sec).c,392 :: 		MOTOR_RUN = 0;
	BCF        PORTB+0, 2
;HMI_Sorter_(min_sec).c,393 :: 		pageState = 0;
	CLRF       _pageState+0
;HMI_Sorter_(min_sec).c,394 :: 		boxes = 0;
	CLRF       _boxes+0
;HMI_Sorter_(min_sec).c,395 :: 		EEPROM_Write(slotA, boxes);                                     // prepare data for the new job (after restart)
	CLRF       FARG_EEPROM_Write_Address+0
	CLRF       FARG_EEPROM_Write_data_+0
	CALL       _EEPROM_Write+0
;HMI_Sorter_(min_sec).c,396 :: 		Lcd_Cmd(_LCD_CLEAR);
	MOVLW      1
	MOVWF      FARG_Lcd_Cmd_out_char+0
	CALL       _Lcd_Cmd+0
;HMI_Sorter_(min_sec).c,397 :: 		Lcd_Out(1,5,"JOB END");
	MOVLW      1
	MOVWF      FARG_Lcd_Out_row+0
	MOVLW      5
	MOVWF      FARG_Lcd_Out_column+0
	MOVLW      ?lstr11_HMI_Sorter__40min_sec_41+0
	MOVWF      FARG_Lcd_Out_text+0
	CALL       _Lcd_Out+0
;HMI_Sorter_(min_sec).c,398 :: 		ACK_EMS = 1;                                                    // Acknowledge on until press reset or power loss
	BSF        PORTA+0, 7
;HMI_Sorter_(min_sec).c,399 :: 		while(1);
L_objectCount103:
	GOTO       L_objectCount103
;HMI_Sorter_(min_sec).c,400 :: 		}
L_objectCount102:
;HMI_Sorter_(min_sec).c,401 :: 		lastPage = 0xFF;                                                    // Force redraw of "RUNNING" labels
	MOVLW      255
	MOVWF      _lastPage+0
;HMI_Sorter_(min_sec).c,402 :: 		refreshUI();
	CALL       _refreshUI+0
;HMI_Sorter_(min_sec).c,403 :: 		}
L_objectCount91:
;HMI_Sorter_(min_sec).c,404 :: 		objFlag = 0;
	CLRF       objectCount_objFlag_L0+0
;HMI_Sorter_(min_sec).c,405 :: 		}
L_objectCount90:
;HMI_Sorter_(min_sec).c,406 :: 		}
	RETURN
; end of _objectCount

_disp_num:

;HMI_Sorter_(min_sec).c,412 :: 		void disp_num(unsigned int num, char row, char col, DispFormat range){          // DispFormat: VAL_UNI, VAL_DEZ, VAL_CEN, VAL_MIL, VAL_DEZM
;HMI_Sorter_(min_sec).c,414 :: 		short noZero = 0;
	CLRF       disp_num_noZero_L0+0
;HMI_Sorter_(min_sec).c,416 :: 		switch(range){
	GOTO       L_disp_num105
;HMI_Sorter_(min_sec).c,418 :: 		case VAL_DEZM:
L_disp_num107:
;HMI_Sorter_(min_sec).c,420 :: 		dezM = (char)(num/10000);
	MOVLW      16
	MOVWF      R4+0
	MOVLW      39
	MOVWF      R4+1
	MOVF       FARG_disp_num_num+0, 0
	MOVWF      R0+0
	MOVF       FARG_disp_num_num+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_U+0
	MOVF       R0+0, 0
	MOVWF      disp_num_dezM_L0+0
;HMI_Sorter_(min_sec).c,421 :: 		num %= 10000;
	MOVLW      16
	MOVWF      R4+0
	MOVLW      39
	MOVWF      R4+1
	MOVF       FARG_disp_num_num+0, 0
	MOVWF      R0+0
	MOVF       FARG_disp_num_num+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVF       R0+0, 0
	MOVWF      FARG_disp_num_num+0
	MOVF       R0+1, 0
	MOVWF      FARG_disp_num_num+1
;HMI_Sorter_(min_sec).c,422 :: 		mil  = (char)(num/1000);
	MOVLW      232
	MOVWF      R4+0
	MOVLW      3
	MOVWF      R4+1
	CALL       _Div_16x16_U+0
	MOVF       R0+0, 0
	MOVWF      disp_num_mil_L0+0
;HMI_Sorter_(min_sec).c,423 :: 		num %= 1000;
	MOVLW      232
	MOVWF      R4+0
	MOVLW      3
	MOVWF      R4+1
	MOVF       FARG_disp_num_num+0, 0
	MOVWF      R0+0
	MOVF       FARG_disp_num_num+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVF       R0+0, 0
	MOVWF      FARG_disp_num_num+0
	MOVF       R0+1, 0
	MOVWF      FARG_disp_num_num+1
;HMI_Sorter_(min_sec).c,424 :: 		cen  = (char)(num/100);
	MOVLW      100
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	CALL       _Div_16x16_U+0
	MOVF       R0+0, 0
	MOVWF      disp_num_cen_L0+0
;HMI_Sorter_(min_sec).c,425 :: 		num %= 100;
	MOVLW      100
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FARG_disp_num_num+0, 0
	MOVWF      R0+0
	MOVF       FARG_disp_num_num+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVF       R0+0, 0
	MOVWF      FARG_disp_num_num+0
	MOVF       R0+1, 0
	MOVWF      FARG_disp_num_num+1
;HMI_Sorter_(min_sec).c,426 :: 		dez  = (char)(num/10);
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	CALL       _Div_16x16_U+0
	MOVF       R0+0, 0
	MOVWF      disp_num_dez_L0+0
;HMI_Sorter_(min_sec).c,427 :: 		uni  = (char)(num%10);
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FARG_disp_num_num+0, 0
	MOVWF      R0+0
	MOVF       FARG_disp_num_num+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVF       R0+0, 0
	MOVWF      disp_num_uni_L0+0
;HMI_Sorter_(min_sec).c,429 :: 		if(!dezM && !noZero)                                                // if variable is zero and noZero is = zero
	MOVF       disp_num_dezM_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num110
	MOVF       disp_num_noZero_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num110
L__disp_num173:
;HMI_Sorter_(min_sec).c,430 :: 		Lcd_Chr(row, col, ' ');                                          // print a blanc space (to delete the left zeroes)
	MOVF       FARG_disp_num_row+0, 0
	MOVWF      FARG_Lcd_Chr_row+0
	MOVF       FARG_disp_num_col+0, 0
	MOVWF      FARG_Lcd_Chr_column+0
	MOVLW      32
	MOVWF      FARG_Lcd_Chr_out_char+0
	CALL       _Lcd_Chr+0
	GOTO       L_disp_num111
L_disp_num110:
;HMI_Sorter_(min_sec).c,432 :: 		Lcd_Chr(row, col, dezM+0x30);                                    // else sum '0' (ASCII) to the variable and print at given row and column
	MOVF       FARG_disp_num_row+0, 0
	MOVWF      FARG_Lcd_Chr_row+0
	MOVF       FARG_disp_num_col+0, 0
	MOVWF      FARG_Lcd_Chr_column+0
	MOVLW      48
	ADDWF      disp_num_dezM_L0+0, 0
	MOVWF      FARG_Lcd_Chr_out_char+0
	CALL       _Lcd_Chr+0
;HMI_Sorter_(min_sec).c,433 :: 		noZero = 1;                                                      // when noZero = 1, all remaining checks will be false in order to fill up the next digits
	MOVLW      1
	MOVWF      disp_num_noZero_L0+0
;HMI_Sorter_(min_sec).c,434 :: 		}
L_disp_num111:
;HMI_Sorter_(min_sec).c,436 :: 		if(!mil && !noZero) Lcd_Chr_Cp(' ');
	MOVF       disp_num_mil_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num114
	MOVF       disp_num_noZero_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num114
L__disp_num172:
	MOVLW      32
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
	GOTO       L_disp_num115
L_disp_num114:
;HMI_Sorter_(min_sec).c,439 :: 		Lcd_Chr_Cp(mil+0x30);
	MOVLW      48
	ADDWF      disp_num_mil_L0+0, 0
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
;HMI_Sorter_(min_sec).c,440 :: 		noZero = 1;
	MOVLW      1
	MOVWF      disp_num_noZero_L0+0
;HMI_Sorter_(min_sec).c,441 :: 		}
L_disp_num115:
;HMI_Sorter_(min_sec).c,443 :: 		if(!cen && !noZero) Lcd_Chr_Cp(' ');
	MOVF       disp_num_cen_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num118
	MOVF       disp_num_noZero_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num118
L__disp_num171:
	MOVLW      32
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
	GOTO       L_disp_num119
L_disp_num118:
;HMI_Sorter_(min_sec).c,446 :: 		Lcd_Chr_Cp(cen+0x30);
	MOVLW      48
	ADDWF      disp_num_cen_L0+0, 0
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
;HMI_Sorter_(min_sec).c,447 :: 		noZero = 1;
	MOVLW      1
	MOVWF      disp_num_noZero_L0+0
;HMI_Sorter_(min_sec).c,448 :: 		}
L_disp_num119:
;HMI_Sorter_(min_sec).c,450 :: 		if(!dez && !noZero) Lcd_Chr_Cp(' ');
	MOVF       disp_num_dez_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num122
	MOVF       disp_num_noZero_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num122
L__disp_num170:
	MOVLW      32
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
	GOTO       L_disp_num123
L_disp_num122:
;HMI_Sorter_(min_sec).c,453 :: 		Lcd_Chr_Cp(dez+0x30);
	MOVLW      48
	ADDWF      disp_num_dez_L0+0, 0
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
;HMI_Sorter_(min_sec).c,454 :: 		noZero = 1;
	MOVLW      1
	MOVWF      disp_num_noZero_L0+0
;HMI_Sorter_(min_sec).c,455 :: 		}
L_disp_num123:
;HMI_Sorter_(min_sec).c,457 :: 		Lcd_Chr_Cp(uni+0x30);                                                   // no test about zero because to print a zero here has to be possible
	MOVLW      48
	ADDWF      disp_num_uni_L0+0, 0
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
;HMI_Sorter_(min_sec).c,458 :: 		break;
	GOTO       L_disp_num106
;HMI_Sorter_(min_sec).c,460 :: 		case VAL_MIL:
L_disp_num124:
;HMI_Sorter_(min_sec).c,462 :: 		mil  = (char)(num/1000);
	MOVLW      232
	MOVWF      R4+0
	MOVLW      3
	MOVWF      R4+1
	MOVF       FARG_disp_num_num+0, 0
	MOVWF      R0+0
	MOVF       FARG_disp_num_num+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_U+0
	MOVF       R0+0, 0
	MOVWF      disp_num_mil_L0+0
;HMI_Sorter_(min_sec).c,463 :: 		num %= 1000;
	MOVLW      232
	MOVWF      R4+0
	MOVLW      3
	MOVWF      R4+1
	MOVF       FARG_disp_num_num+0, 0
	MOVWF      R0+0
	MOVF       FARG_disp_num_num+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVF       R0+0, 0
	MOVWF      FARG_disp_num_num+0
	MOVF       R0+1, 0
	MOVWF      FARG_disp_num_num+1
;HMI_Sorter_(min_sec).c,464 :: 		cen  = (char)(num/100);
	MOVLW      100
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	CALL       _Div_16x16_U+0
	MOVF       R0+0, 0
	MOVWF      disp_num_cen_L0+0
;HMI_Sorter_(min_sec).c,465 :: 		num %= 100;
	MOVLW      100
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FARG_disp_num_num+0, 0
	MOVWF      R0+0
	MOVF       FARG_disp_num_num+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVF       R0+0, 0
	MOVWF      FARG_disp_num_num+0
	MOVF       R0+1, 0
	MOVWF      FARG_disp_num_num+1
;HMI_Sorter_(min_sec).c,466 :: 		dez  = (char)(num/10);
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	CALL       _Div_16x16_U+0
	MOVF       R0+0, 0
	MOVWF      disp_num_dez_L0+0
;HMI_Sorter_(min_sec).c,467 :: 		uni  = (char)(num%10);
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FARG_disp_num_num+0, 0
	MOVWF      R0+0
	MOVF       FARG_disp_num_num+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVF       R0+0, 0
	MOVWF      disp_num_uni_L0+0
;HMI_Sorter_(min_sec).c,469 :: 		if(!mil && !noZero) Lcd_Chr(row, col, ' ');
	MOVF       disp_num_mil_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num127
	MOVF       disp_num_noZero_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num127
L__disp_num169:
	MOVF       FARG_disp_num_row+0, 0
	MOVWF      FARG_Lcd_Chr_row+0
	MOVF       FARG_disp_num_col+0, 0
	MOVWF      FARG_Lcd_Chr_column+0
	MOVLW      32
	MOVWF      FARG_Lcd_Chr_out_char+0
	CALL       _Lcd_Chr+0
	GOTO       L_disp_num128
L_disp_num127:
;HMI_Sorter_(min_sec).c,472 :: 		Lcd_Chr(row,col,mil+0x30);
	MOVF       FARG_disp_num_row+0, 0
	MOVWF      FARG_Lcd_Chr_row+0
	MOVF       FARG_disp_num_col+0, 0
	MOVWF      FARG_Lcd_Chr_column+0
	MOVLW      48
	ADDWF      disp_num_mil_L0+0, 0
	MOVWF      FARG_Lcd_Chr_out_char+0
	CALL       _Lcd_Chr+0
;HMI_Sorter_(min_sec).c,473 :: 		noZero = 1;
	MOVLW      1
	MOVWF      disp_num_noZero_L0+0
;HMI_Sorter_(min_sec).c,474 :: 		}
L_disp_num128:
;HMI_Sorter_(min_sec).c,476 :: 		if(!cen && !noZero) Lcd_Chr_Cp(' ');
	MOVF       disp_num_cen_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num131
	MOVF       disp_num_noZero_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num131
L__disp_num168:
	MOVLW      32
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
	GOTO       L_disp_num132
L_disp_num131:
;HMI_Sorter_(min_sec).c,479 :: 		Lcd_Chr_Cp(cen+0x30);
	MOVLW      48
	ADDWF      disp_num_cen_L0+0, 0
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
;HMI_Sorter_(min_sec).c,480 :: 		noZero = 1;
	MOVLW      1
	MOVWF      disp_num_noZero_L0+0
;HMI_Sorter_(min_sec).c,481 :: 		}
L_disp_num132:
;HMI_Sorter_(min_sec).c,483 :: 		if(!dez && !noZero) Lcd_Chr_Cp(' ');
	MOVF       disp_num_dez_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num135
	MOVF       disp_num_noZero_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num135
L__disp_num167:
	MOVLW      32
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
	GOTO       L_disp_num136
L_disp_num135:
;HMI_Sorter_(min_sec).c,486 :: 		Lcd_Chr_Cp(dez+0x30);
	MOVLW      48
	ADDWF      disp_num_dez_L0+0, 0
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
;HMI_Sorter_(min_sec).c,487 :: 		noZero = 1;
	MOVLW      1
	MOVWF      disp_num_noZero_L0+0
;HMI_Sorter_(min_sec).c,488 :: 		}
L_disp_num136:
;HMI_Sorter_(min_sec).c,490 :: 		Lcd_Chr_Cp(uni+0x30);
	MOVLW      48
	ADDWF      disp_num_uni_L0+0, 0
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
;HMI_Sorter_(min_sec).c,491 :: 		break;
	GOTO       L_disp_num106
;HMI_Sorter_(min_sec).c,493 :: 		case VAL_CEN:
L_disp_num137:
;HMI_Sorter_(min_sec).c,495 :: 		cen  = (char)(num/100);
	MOVLW      100
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FARG_disp_num_num+0, 0
	MOVWF      R0+0
	MOVF       FARG_disp_num_num+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_U+0
	MOVF       R0+0, 0
	MOVWF      disp_num_cen_L0+0
;HMI_Sorter_(min_sec).c,496 :: 		num %= 100;
	MOVLW      100
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FARG_disp_num_num+0, 0
	MOVWF      R0+0
	MOVF       FARG_disp_num_num+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVF       R0+0, 0
	MOVWF      FARG_disp_num_num+0
	MOVF       R0+1, 0
	MOVWF      FARG_disp_num_num+1
;HMI_Sorter_(min_sec).c,497 :: 		dez  = (char)(num/10);
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	CALL       _Div_16x16_U+0
	MOVF       R0+0, 0
	MOVWF      disp_num_dez_L0+0
;HMI_Sorter_(min_sec).c,498 :: 		uni  = (char)(num%10);
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FARG_disp_num_num+0, 0
	MOVWF      R0+0
	MOVF       FARG_disp_num_num+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVF       R0+0, 0
	MOVWF      disp_num_uni_L0+0
;HMI_Sorter_(min_sec).c,500 :: 		if(!cen && !noZero) Lcd_Chr(row, col, ' ');
	MOVF       disp_num_cen_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num140
	MOVF       disp_num_noZero_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num140
L__disp_num166:
	MOVF       FARG_disp_num_row+0, 0
	MOVWF      FARG_Lcd_Chr_row+0
	MOVF       FARG_disp_num_col+0, 0
	MOVWF      FARG_Lcd_Chr_column+0
	MOVLW      32
	MOVWF      FARG_Lcd_Chr_out_char+0
	CALL       _Lcd_Chr+0
	GOTO       L_disp_num141
L_disp_num140:
;HMI_Sorter_(min_sec).c,503 :: 		Lcd_Chr(row, col, cen+0x30);
	MOVF       FARG_disp_num_row+0, 0
	MOVWF      FARG_Lcd_Chr_row+0
	MOVF       FARG_disp_num_col+0, 0
	MOVWF      FARG_Lcd_Chr_column+0
	MOVLW      48
	ADDWF      disp_num_cen_L0+0, 0
	MOVWF      FARG_Lcd_Chr_out_char+0
	CALL       _Lcd_Chr+0
;HMI_Sorter_(min_sec).c,504 :: 		noZero = 1;
	MOVLW      1
	MOVWF      disp_num_noZero_L0+0
;HMI_Sorter_(min_sec).c,505 :: 		}
L_disp_num141:
;HMI_Sorter_(min_sec).c,507 :: 		if(!dez && !noZero) Lcd_Chr_Cp(' ');
	MOVF       disp_num_dez_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num144
	MOVF       disp_num_noZero_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num144
L__disp_num165:
	MOVLW      32
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
	GOTO       L_disp_num145
L_disp_num144:
;HMI_Sorter_(min_sec).c,510 :: 		Lcd_Chr_Cp(dez+0x30);
	MOVLW      48
	ADDWF      disp_num_dez_L0+0, 0
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
;HMI_Sorter_(min_sec).c,511 :: 		noZero = 1;
	MOVLW      1
	MOVWF      disp_num_noZero_L0+0
;HMI_Sorter_(min_sec).c,512 :: 		}
L_disp_num145:
;HMI_Sorter_(min_sec).c,514 :: 		Lcd_Chr_Cp(uni+0x30);
	MOVLW      48
	ADDWF      disp_num_uni_L0+0, 0
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
;HMI_Sorter_(min_sec).c,515 :: 		break;
	GOTO       L_disp_num106
;HMI_Sorter_(min_sec).c,517 :: 		case VAL_DEZ:
L_disp_num146:
;HMI_Sorter_(min_sec).c,519 :: 		dez  = (char)(num/10);
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FARG_disp_num_num+0, 0
	MOVWF      R0+0
	MOVF       FARG_disp_num_num+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_U+0
	MOVF       R0+0, 0
	MOVWF      disp_num_dez_L0+0
;HMI_Sorter_(min_sec).c,520 :: 		uni  = (char)(num%10);
	MOVLW      10
	MOVWF      R4+0
	MOVLW      0
	MOVWF      R4+1
	MOVF       FARG_disp_num_num+0, 0
	MOVWF      R0+0
	MOVF       FARG_disp_num_num+1, 0
	MOVWF      R0+1
	CALL       _Div_16x16_U+0
	MOVF       R8+0, 0
	MOVWF      R0+0
	MOVF       R8+1, 0
	MOVWF      R0+1
	MOVF       R0+0, 0
	MOVWF      disp_num_uni_L0+0
;HMI_Sorter_(min_sec).c,522 :: 		if(!dez && !noZero) Lcd_Chr(row, col, ' ');
	MOVF       disp_num_dez_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num149
	MOVF       disp_num_noZero_L0+0, 0
	BTFSS      STATUS+0, 2
	GOTO       L_disp_num149
L__disp_num164:
	MOVF       FARG_disp_num_row+0, 0
	MOVWF      FARG_Lcd_Chr_row+0
	MOVF       FARG_disp_num_col+0, 0
	MOVWF      FARG_Lcd_Chr_column+0
	MOVLW      32
	MOVWF      FARG_Lcd_Chr_out_char+0
	CALL       _Lcd_Chr+0
	GOTO       L_disp_num150
L_disp_num149:
;HMI_Sorter_(min_sec).c,525 :: 		Lcd_Chr(row, col, dez+0x30);
	MOVF       FARG_disp_num_row+0, 0
	MOVWF      FARG_Lcd_Chr_row+0
	MOVF       FARG_disp_num_col+0, 0
	MOVWF      FARG_Lcd_Chr_column+0
	MOVLW      48
	ADDWF      disp_num_dez_L0+0, 0
	MOVWF      FARG_Lcd_Chr_out_char+0
	CALL       _Lcd_Chr+0
;HMI_Sorter_(min_sec).c,526 :: 		noZero = 1;
	MOVLW      1
	MOVWF      disp_num_noZero_L0+0
;HMI_Sorter_(min_sec).c,527 :: 		}
L_disp_num150:
;HMI_Sorter_(min_sec).c,529 :: 		Lcd_Chr_Cp(uni+0x30);
	MOVLW      48
	ADDWF      disp_num_uni_L0+0, 0
	MOVWF      FARG_Lcd_Chr_CP_out_char+0
	CALL       _Lcd_Chr_CP+0
;HMI_Sorter_(min_sec).c,530 :: 		break;
	GOTO       L_disp_num106
;HMI_Sorter_(min_sec).c,532 :: 		case VAL_UNI:
L_disp_num151:
;HMI_Sorter_(min_sec).c,533 :: 		Lcd_Chr(row, col, num+0x30);
	MOVF       FARG_disp_num_row+0, 0
	MOVWF      FARG_Lcd_Chr_row+0
	MOVF       FARG_disp_num_col+0, 0
	MOVWF      FARG_Lcd_Chr_column+0
	MOVLW      48
	ADDWF      FARG_disp_num_num+0, 0
	MOVWF      FARG_Lcd_Chr_out_char+0
	CALL       _Lcd_Chr+0
;HMI_Sorter_(min_sec).c,535 :: 		break;
	GOTO       L_disp_num106
;HMI_Sorter_(min_sec).c,537 :: 		default:
L_disp_num152:
;HMI_Sorter_(min_sec).c,538 :: 		Lcd_Chr(row, col, num+0x30);
	MOVF       FARG_disp_num_row+0, 0
	MOVWF      FARG_Lcd_Chr_row+0
	MOVF       FARG_disp_num_col+0, 0
	MOVWF      FARG_Lcd_Chr_column+0
	MOVLW      48
	ADDWF      FARG_disp_num_num+0, 0
	MOVWF      FARG_Lcd_Chr_out_char+0
	CALL       _Lcd_Chr+0
;HMI_Sorter_(min_sec).c,539 :: 		}
	GOTO       L_disp_num106
L_disp_num105:
	MOVF       FARG_disp_num_range+0, 0
	XORLW      4
	BTFSC      STATUS+0, 2
	GOTO       L_disp_num107
	MOVF       FARG_disp_num_range+0, 0
	XORLW      3
	BTFSC      STATUS+0, 2
	GOTO       L_disp_num124
	MOVF       FARG_disp_num_range+0, 0
	XORLW      2
	BTFSC      STATUS+0, 2
	GOTO       L_disp_num137
	MOVF       FARG_disp_num_range+0, 0
	XORLW      1
	BTFSC      STATUS+0, 2
	GOTO       L_disp_num146
	MOVF       FARG_disp_num_range+0, 0
	XORLW      0
	BTFSC      STATUS+0, 2
	GOTO       L_disp_num151
	GOTO       L_disp_num152
L_disp_num106:
;HMI_Sorter_(min_sec).c,540 :: 		}
	RETURN
; end of _disp_num

_disp_blink:

;HMI_Sorter_(min_sec).c,545 :: 		void disp_blink(char row, char col){
;HMI_Sorter_(min_sec).c,546 :: 		if(row == 1) Lcd_Cmd(0x80 + col);                                         // Force Address jump (This stops the "auto-increment" from sticking)
	MOVF       FARG_disp_blink_row+0, 0
	XORLW      1
	BTFSS      STATUS+0, 2
	GOTO       L_disp_blink153
	MOVF       FARG_disp_blink_col+0, 0
	ADDLW      128
	MOVWF      FARG_Lcd_Cmd_out_char+0
	CALL       _Lcd_Cmd+0
	GOTO       L_disp_blink154
L_disp_blink153:
;HMI_Sorter_(min_sec).c,547 :: 		else         Lcd_Cmd(0xC0 + col);
	MOVF       FARG_disp_blink_col+0, 0
	ADDLW      192
	MOVWF      FARG_Lcd_Cmd_out_char+0
	CALL       _Lcd_Cmd+0
L_disp_blink154:
;HMI_Sorter_(min_sec).c,549 :: 		Lcd_Cmd(0x0D);                                                             // 0000 1101 = 0x0D = display ON, cursor OFF and blink ON
	MOVLW      13
	MOVWF      FARG_Lcd_Cmd_out_char+0
	CALL       _Lcd_Cmd+0
;HMI_Sorter_(min_sec).c,550 :: 		delay_us(100);
	MOVLW      33
	MOVWF      R13+0
L_disp_blink155:
	DECFSZ     R13+0, 1
	GOTO       L_disp_blink155
;HMI_Sorter_(min_sec).c,551 :: 		}
	RETURN
; end of _disp_blink
